package main

import (
	"todo-api/cmd"
)

func main() {
	cmd.Execute()
}
